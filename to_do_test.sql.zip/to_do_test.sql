-- phpMyAdmin SQL Dump
-- version 4.4.11
-- http://www.phpmyadmin.net
--
-- Host: localhost:8080
-- Generation Time: Aug 24, 2015 at 11:52 PM
-- Server version: 5.6.26
-- PHP Version: 5.6.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `to_do_test`
--
CREATE DATABASE IF NOT EXISTS `to_do_test` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `to_do_test`;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=920 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `categories_tasks`
--

CREATE TABLE IF NOT EXISTS `categories_tasks` (
  `id` bigint(20) unsigned NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `task_id` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=219 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `categories_tasks`
--

INSERT INTO `categories_tasks` (`id`, `category_id`, `task_id`) VALUES
(1, 325, 68),
(2, 326, 69),
(3, 326, 3),
(4, 340, 81),
(5, 341, 82),
(6, 341, 3),
(7, 355, 94),
(8, 356, 95),
(9, 370, 107),
(10, 371, 108),
(11, 385, 120),
(12, 386, 121),
(13, 400, 133),
(14, 401, 134),
(15, 415, 146),
(16, 416, 147),
(17, 430, 159),
(18, 431, 160),
(19, 445, 172),
(20, 446, 173),
(21, 447, 185),
(22, 448, 186),
(23, 449, 187),
(24, 450, 188),
(25, 450, 189),
(26, 464, 190),
(27, 465, 191),
(28, 465, 192),
(29, 479, 193),
(30, 480, 194),
(31, 480, 195),
(32, 494, 196),
(33, 495, 197),
(34, 495, 198),
(35, 509, 210),
(36, 510, 211),
(37, 510, 212),
(38, 525, 224),
(39, 526, 225),
(40, 526, 226),
(41, 527, 527),
(42, 528, 529),
(43, 529, 529),
(44, 543, 238),
(45, 544, 239),
(46, 544, 240),
(47, 545, 545),
(48, 546, 547),
(49, 547, 547),
(50, 559, 252),
(51, 560, 253),
(52, 560, 254),
(53, 562, 562),
(54, 563, 564),
(55, 564, 564),
(56, 577, 266),
(57, 578, 267),
(58, 578, 268),
(59, 580, 580),
(60, 581, 582),
(61, 582, 582),
(62, 583, 280),
(63, 595, 281),
(64, 596, 282),
(65, 596, 283),
(66, 597, 284),
(67, 598, 598),
(68, 599, 600),
(69, 600, 600),
(70, 601, 296),
(71, 613, 297),
(72, 614, 298),
(73, 614, 299),
(75, 616, 616),
(76, 617, 618),
(77, 618, 618),
(79, 631, 313),
(80, 632, 314),
(81, 632, 315),
(83, 634, 634),
(84, 635, 636),
(85, 636, 636),
(87, 649, 329),
(88, 650, 330),
(89, 650, 331),
(91, 652, 652),
(92, 653, 654),
(93, 654, 654),
(95, 667, 345),
(96, 668, 346),
(97, 668, 347),
(99, 670, 670),
(100, 671, 672),
(101, 672, 672),
(103, 685, 362),
(104, 686, 363),
(105, 686, 364),
(107, 688, 688),
(108, 689, 690),
(109, 690, 690),
(111, 703, 379),
(112, 704, 380),
(113, 704, 381),
(115, 706, 706),
(116, 707, 708),
(117, 708, 708),
(119, 721, 396),
(120, 722, 397),
(121, 722, 398),
(123, 724, 724),
(124, 725, 726),
(125, 726, 726),
(127, 739, 414),
(128, 740, 415),
(129, 740, 416),
(131, 742, 742),
(132, 743, 744),
(133, 744, 744),
(135, 757, 432),
(136, 758, 433),
(137, 758, 434),
(139, 760, 760),
(140, 761, 762),
(141, 762, 762),
(143, 775, 450),
(144, 776, 451),
(145, 776, 452),
(147, 778, 778),
(148, 779, 780),
(149, 780, 780),
(151, 793, 468),
(152, 794, 469),
(153, 794, 470),
(155, 796, 796),
(156, 797, 798),
(157, 798, 798),
(159, 811, 486),
(160, 812, 487),
(161, 812, 488),
(163, 814, 814),
(164, 815, 816),
(165, 816, 816),
(167, 829, 504),
(168, 830, 505),
(169, 830, 506),
(171, 832, 832),
(172, 833, 834),
(173, 834, 834),
(175, 847, 522),
(176, 848, 523),
(177, 848, 524),
(179, 850, 850),
(180, 851, 852),
(181, 852, 852),
(183, 865, 540),
(184, 866, 541),
(185, 866, 542),
(187, 868, 868),
(188, 869, 870),
(189, 870, 870),
(191, 883, 558),
(192, 884, 559),
(193, 884, 560),
(195, 886, 886),
(196, 887, 888),
(197, 888, 888),
(199, 901, 576),
(200, 902, 577),
(201, 902, 578),
(203, 904, 904),
(204, 905, 906),
(205, 906, 906),
(207, 908, 908),
(208, 909, 910),
(209, 910, 910),
(211, 912, 912),
(212, 913, 914),
(213, 914, 914),
(215, 916, 916),
(216, 917, 918),
(217, 918, 918);

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

CREATE TABLE IF NOT EXISTS `tasks` (
  `id` bigint(20) unsigned NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `completed` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=662 DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `categories_tasks`
--
ALTER TABLE `categories_tasks`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=920;
--
-- AUTO_INCREMENT for table `categories_tasks`
--
ALTER TABLE `categories_tasks`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=219;
--
-- AUTO_INCREMENT for table `tasks`
--
ALTER TABLE `tasks`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=662;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
